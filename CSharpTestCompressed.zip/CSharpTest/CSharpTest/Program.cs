﻿// See https://aka.ms/new-console-template for more information

using System;
using System.ComponentModel.Design;
using System.Diagnostics.Tracing;
using System.Transactions;

Console.WriteLine("[1] Maths Stuff");
Console.WriteLine("[2] Input Stuff");
Console.WriteLine("[3] Roll a Dice");
Console.WriteLine("[4] Spam Numbers");
Console.WriteLine("[5] Make a Shape");
Console.WriteLine("[6] Number Guessing Game");
Console.Write("Option: ");
int firstOption = Convert.ToInt32(Console.ReadLine());

if (firstOption == 1)
{
    Console.WriteLine("[1] Random Maths");
    Console.WriteLine("[2] Custom Equations");
    int OptionSelection1 = Convert.ToInt32(Console.ReadLine());
    if (OptionSelection1 == 1)
    {
        Console.WriteLine("To generate a value for x, press enter!");
        String enterHit = Console.ReadLine();
        if (enterHit == "")
        {
            Random y = new Random();
            double x = y.NextDouble();
            Console.WriteLine("The value of x is " + x + "!");
            Console.WriteLine("To get x to the power of whatever you want, enter 1");
            Console.WriteLine("To get the square root of x, enter 2");
            Console.WriteLine("To get the value of x rounded, enter 3");
            Console.WriteLine("To get the value of x rounded up, enter 4");
            Console.WriteLine("To get the value of x rounded down, enter 5");
            String enterOption = Console.ReadLine();

            if (enterOption == "1")
            {
                Console.WriteLine("For x to the power of 1, enter 1");
                Console.WriteLine("For x to the power of 2, enter 2");
                Console.WriteLine("For x to the power of 3, enter 3");
                Console.WriteLine("For x to the power of 4, enter 4");
                Console.WriteLine("For x to the power of 5, enter 5");
                String value1 = Console.ReadLine();

                if (value1 == "1")
                {
                    double power1 = Math.Pow(x, 1);
                    Console.WriteLine("X to the power of 1 is " + power1);
                }
                else if (value1 == "2")
                {
                    double power2 = Math.Pow(x, 2);
                    Console.WriteLine("X to the power of 2 is " + power2);
                }
                else if (value1 == "3")
                {
                    double power3 = Math.Pow(x, 3);
                    Console.WriteLine("X to the power of 3 is " + power3);
                }
                else if (value1 == "4")
                {
                    double power4 = Math.Pow(x, 4);
                    Console.WriteLine("X to the power of 4 is " + power4);
                }
                else if (value1 == "5")
                {
                    double power5 = Math.Pow(x, 5);
                    Console.WriteLine("X to the power of 5 is " + power5);
                }
                else
                {
                    Console.WriteLine("You haven't entered one of the options above!");
                }
            }



            if (enterOption == "2")
            {
                double squareRoot = Math.Sqrt(x);
                Console.WriteLine("The square root of x is " + squareRoot);
            }

            if (enterOption == "3")
            {
                double rounded = Math.Round(x);
                Console.WriteLine("X rounded is " + rounded);
            }

            if (enterOption == "4")
            {
                double roundUp = Math.Ceiling(x);
                Console.WriteLine("X rounded up is " + roundUp);
            }

            if (enterOption == "5")
            {
                double roundDown = Math.Floor(x);
                Console.WriteLine("X rounded down is " + roundDown);
            }
        }
    }
    if (OptionSelection1 == 2)
    {
        Console.WriteLine("For custom addition, press 1");
        Console.WriteLine("For custom subtraction, press 2");
        Console.WriteLine("For custom division, press 3");
        Console.WriteLine("For custom multiplication, press 4");
        int OS2 = Convert.ToInt32(Console.ReadLine());
        if (OS2 == 1)
        {
            Console.WriteLine("To add 2 custom numbers together, press 1");
            Console.WriteLine("To add 3 custom numbers together, press 2");
            Console.WriteLine("To add 4 custom numbers together, press 3");
            Console.WriteLine("To add 5 custom numbers together, press 4");
            String OS3 = Console.ReadLine();
            if (OS3 == "1")
            {
                Console.Write("Enter first number: ");
                double OS4 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double OS5 = Convert.ToDouble(Console.ReadLine());
                double Answer = OS4 + OS5;
                Console.WriteLine(OS4 + " + " + OS5 + " = " + Answer);
            }
            if (OS3 == "2")
            {
                Console.Write("Enter first number: ");
                double OS6 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double OS7 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double OS8 = Convert.ToDouble(Console.ReadLine());
                double Answer2 = OS6 + OS7 + OS8;
                Console.WriteLine(OS6 + "+" + OS7 + "+" + OS8 + "=" + Answer2);
            }
            if (OS3 == "3")
            {
                Console.Write("Enter first number: ");
                double OS1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double OS2scnd = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double OS3thrd = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double OS4 = Convert.ToDouble(Console.ReadLine());
                double Answer = OS1 + OS2scnd + OS3thrd + OS4;
                Console.WriteLine(OS1 + " + " + OS2scnd + " + " + OS3thrd + " + " + OS4 + " = " + Answer);
            }
            if (OS3 == "4")
            {
                Console.Write("Enter first number: ");
                double OS1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double OS2scnd = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double OS3thrd = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double OS4 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fifth number: ");
                double OS5 = Convert.ToDouble(Console.ReadLine());
                double Answer = OS1 + OS2scnd + OS3thrd + OS4 + OS5;
                Console.WriteLine(OS1 + " + " + OS2scnd + " + " + OS3thrd + " + " + OS4 + " + " + OS5 + " = " + Answer);
            }
        }
        if (OS2 == 2)
        {
            Console.WriteLine("To subtract 2 numbers, enter 1");
            Console.WriteLine("To subtract 3 numbers, enter 2");
            Console.WriteLine("To subtract 4 numbers, enter 3");
            Console.WriteLine("To subtract 5 numbers, enter 4");
            int subtractAmount = Convert.ToInt32(Console.ReadLine());
            if (subtractAmount == 1)
            {
                Console.Write("Enter first number: ");
                double subtract1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double subtract2 = Convert.ToDouble(Console.ReadLine());
                double answer = subtract1 - subtract2;
                Console.WriteLine(subtract1 + " - " + subtract2 + " = " + answer);
            }
            if (subtractAmount == 2)
            {
                Console.Write("Enter first number: ");
                double subtract1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double subtract2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double subtract3 = Convert.ToDouble(Console.ReadLine());
                double answer = subtract1 - subtract2 - subtract3;
                Console.WriteLine(subtract1 + " - " + subtract2 + " - " + subtract3 + " = " + answer);
            }
            if (subtractAmount == 3)
            {
                Console.Write("Enter first number: ");
                double subtract1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double subtract2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double subtract3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double subtract4 = Convert.ToDouble(Console.ReadLine());
                double answer = subtract1 - subtract2 - subtract3 - subtract4;
                Console.WriteLine(subtract1 + " - " + subtract2 + " - " + subtract3 + " - " + subtract4 + " = " + answer);
            }
            if (subtractAmount == 4)
            {
                Console.Write("Enter first number: ");
                double subtract1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double subtract2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double subtract3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double subtract4 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fith number: ");
                double subtract5 = Convert.ToDouble(Console.ReadLine());
                double answer = subtract1 - subtract2 - subtract3 - subtract4 - subtract5;
                Console.WriteLine(subtract1 + " - " + subtract2 + " - " + subtract3 + " - " + subtract4 + " - " + subtract5 + " = " + answer);
            }

        }
        if (OS2 == 3)
        {
            Console.WriteLine("To divide 2 numbers, enter 1");
            Console.WriteLine("To divide 3 numbers, enter 2");
            Console.WriteLine("To divide 4 numbers, enter 3");
            Console.WriteLine("To divide 5 numbers, enter 4");
            int divideAmount = Convert.ToInt32(Console.ReadLine());
            if (divideAmount == 1)
            {
                Console.Write("Enter first number: ");
                double divide1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double divide2 = Convert.ToDouble(Console.ReadLine());
                double answer = divide1 / divide2;
                Console.WriteLine(divide1 + " ÷ " + divide2 + " = " + answer);
            }
            if (divideAmount == 2)
            {
                Console.Write("Enter first number: ");
                double divide1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double divide2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double divide3 = Convert.ToDouble(Console.ReadLine());
                double answer = divide1 / divide2 / divide3;
                Console.WriteLine(divide1 + " ÷ " + divide2 + " ÷ " + divide3 + " = " + answer);
            }
            if (divideAmount == 3)
            {
                Console.Write("Enter first number: ");
                double divide1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double divide2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double divide3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double divide4 = Convert.ToDouble(Console.ReadLine());
                double answer = divide1 / divide2 / divide3 / divide4;
                Console.WriteLine(divide1 + " ÷ " + divide2 + " ÷ " + divide3 + " ÷ " + divide4 + " = " + answer);
            }
            if (divideAmount == 4)
            {
                Console.Write("Enter first number: ");
                double divide1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double divide2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double divide3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double divide4 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fith number: ");
                double divide5 = Convert.ToDouble(Console.ReadLine());
                double answer = divide1 / divide2 / divide3 / divide4 / divide5;
                Console.WriteLine(divide1 + " ÷ " + divide2 + " ÷ " + divide3 + " ÷ " + divide4 + " ÷ " + divide5 + " = " + answer);
            }

        }
        if (OS2 == 4)
        {
            Console.WriteLine("To multiply 2 numbers, enter 1");
            Console.WriteLine("To multiply 3 numbers, enter 2");
            Console.WriteLine("To multiply 4 numbers, enter 3");
            Console.WriteLine("To multiply 5 numbers, enter 4");
            int multiplyAmount = Convert.ToInt32(Console.ReadLine());
            if (multiplyAmount == 1)
            {
                Console.Write("Enter first number: ");
                double multiply1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double multiply2 = Convert.ToDouble(Console.ReadLine());
                double answer = multiply1 * multiply2;
                Console.WriteLine(multiply1 + " x " + multiply2 + " = " + answer);
            }
            if (multiplyAmount == 2)
            {
                Console.Write("Enter first number: ");
                double multiply1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double multiply2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double multiply3 = Convert.ToDouble(Console.ReadLine());
                double answer = multiply1 * multiply2 * multiply3;
                Console.WriteLine(multiply1 + " x " + multiply2 + " x " + multiply3 + " = " + answer);
            }
            if (multiplyAmount == 3)
            {
                Console.Write("Enter first number: ");
                double multiply1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double multiply2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double multiply3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double multiply4 = Convert.ToDouble(Console.ReadLine());
                double answer = multiply1 * multiply2 * multiply3 * multiply4;
                Console.WriteLine(multiply1 + " x " + multiply2 + " x " + multiply3 + " x " + multiply4 + " = " + answer);
            }
            if (multiplyAmount == 4)
            {
                Console.Write("Enter first number: ");
                double multiply1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter second number: ");
                double multiply2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter third number: ");
                double multiply3 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fourth number: ");
                double multiply4 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter fith number: ");
                double multiply5 = Convert.ToDouble(Console.ReadLine());
                double answer = multiply1 * multiply2 * multiply3 * multiply4 * multiply5;
                Console.WriteLine(multiply1 + " x " + multiply2 + " x " + multiply3 + " x " + multiply4 + " x " + multiply5 + " = " + answer);
            }

        }
    }
}

if (firstOption == 2)
{
    Console.WriteLine("What is your name?");
    String inputName = Console.ReadLine();
    while (inputName == "")
    {
        Console.WriteLine("Please enter your name");
        inputName = Console.ReadLine();
    }
    Console.WriteLine("How old are you?");
    String inputAge = Console.ReadLine();
    while (inputAge == "")
    {
        Console.WriteLine("Please enter your age");
        inputAge = Console.ReadLine();
    }
    Console.WriteLine("What is your favourite colour?");
    String favColour = Console.ReadLine();
    while (favColour == "")
    {
        Console.WriteLine("Please enter your favourite colour");
        favColour = Console.ReadLine();
    }
    Console.WriteLine("What is your favourite food?");
    String favFood = Console.ReadLine();
    while (favFood == "")
    {
        Console.WriteLine("Please enter your favourite food");
        favFood = Console.ReadLine();
    }
    Console.WriteLine("What is something you enjoy?");
    String hobby = Console.ReadLine();
    while (hobby == "")
    {
        Console.WriteLine("Please enter something you enjoy");
        hobby = Console.ReadLine();
    }
    Console.WriteLine("Hello " + inputName + "!");
    Console.WriteLine("You are " + inputAge + " years old");
    Console.WriteLine("Your favourite colour is " + favColour);
    Console.WriteLine("Your favourite food is " + favFood);
    Console.WriteLine("You enjoy " + hobby);
}
if (firstOption == 3)
{
    Console.WriteLine("[1] 6 sided dice");
    Console.WriteLine("[2] 32 sided dice");
    Console.WriteLine("[3] Custom");
    Console.Write("Option: ");
    int diceFirstOption = Convert.ToInt32(Console.ReadLine());
    if (diceFirstOption == 1)
    {
        Console.WriteLine("To roll the dice 1 time, enter 1");
        Console.WriteLine("To roll the dice 2 times, enter 2");
        Console.WriteLine("To roll the dice 3 times, enter 3");
        int dice1Amount = Convert.ToInt32(Console.ReadLine());
        if (dice1Amount == 1)
        {
            Random Random1 = new Random();
            int random1first = Random1.Next(1, 7);
            Console.WriteLine("The dice landed on " + random1first);
        }
        if (dice1Amount == 2)
        {
            Random random = new Random();
            int randomfirst = random.Next(1, 7);
            int randomsecond = random.Next(1, 7);
            Console.WriteLine("The dice landed on " + randomfirst + " and " + randomsecond);
        }
        if (dice1Amount == 3)
        {
            Random random = new Random();
            int randomfirst = random.Next(1, 7);
            int randomsecond = random.Next(1, 7);
            int randomthird = random.Next(1, 7);
            Console.WriteLine("The dice landed on " + randomfirst + ", " + randomsecond + " and " + randomthird);
        }
        {

        }

    }

    if (diceFirstOption == 2)
    {
        Console.WriteLine("To roll the dice 1 time, enter 1");
        Console.WriteLine("To roll the dice 2 times, enter 2");
        Console.WriteLine("To roll the dice 3 times, enter 3");
        int diceRollsAmount = Convert.ToInt32(Console.ReadLine());
        if (diceRollsAmount == 1)
        {
            Random random = new Random();
            int randomFirst = random.Next(1, 33);
            Console.WriteLine("The dice landed on " + randomFirst);
        }
        if (diceRollsAmount == 2)
        {
            Random random = new Random();
            int randomFirst = random.Next(1, 33);
            int randomSecond = random.Next(1, 33);
            Console.WriteLine("The dice landed on " + randomFirst + " and " + randomSecond);
        }
        if (diceRollsAmount == 3)
        {
            Random random = new Random();
            int randomFirst = random.Next(1, 33);
            int randomSecond = random.Next(1, 33);
            int randomThird = random.Next(1, 33);
            Console.WriteLine("The dice landed on " + randomFirst + ", " + randomSecond + " and " + randomThird);
        }
    }
    if (diceFirstOption == 3)
    {
        Console.Write("Enter minimum number: ");
        int customMin = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter maximum number: ");
        int customMax = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Your number will be between " + customMin + " and " + customMax);
        Console.WriteLine("To roll the dice 1 time, enter 1");
        Console.WriteLine("To roll the dice 2 times, enter 2");
        Console.WriteLine("To roll the dice 3 times, enter 3");
        int diceRollsAmount = Convert.ToInt32(Console.ReadLine());
        if (diceRollsAmount == 1)
        {
            Console.WriteLine("Enter anything to roll the dice");
            Console.ReadLine();
            Random random = new Random();
            int randomFirst = random.Next(customMin, customMax);
            Console.WriteLine("The dice landed on " + randomFirst);
        }
        if (diceRollsAmount == 2)
        {
            Console.WriteLine("Enter anything to roll the dice");
            Console.ReadLine();
            Random random = new Random();
            int random1 = random.Next(customMin, customMax);
            int random2 = random.Next(customMin, customMax);
            Console.WriteLine("The dice landed on " + random1 + " and " + random2);
        }
        if (diceRollsAmount == 3)
        {
            Console.WriteLine("Enter anything to roll the dice");
            Console.ReadLine();
            Random random = new Random();
            int random1 = random.Next(customMin, customMax);
            int random2 = random.Next(customMin, customMax);
            int random3 = random.Next(customMin, customMax);
            Console.WriteLine("The dice landed on " + random1 + ", " + random2 + " and " + random3);
        }
    }
}
if (firstOption == 4)
{
    Console.WriteLine("When ready, type anything to start spamming numbers");
    Console.ReadLine();
    for (int spam = 1; spam <= 1000000000; spam++)
    {
        Console.WriteLine(spam);
    }

}

if (firstOption == 5)
{
    Console.Write("How many columns?: ");
    int columns = Convert.ToInt32(Console.ReadLine());
    Console.Write("How many rows?: ");
    int rows = Convert.ToInt32(Console.ReadLine());
    Console.Write("What symbol?: ");
    char symbol = Convert.ToChar(Console.ReadLine());
    for (int a = 0; a < columns; a++)
    {
        for (int b = 0; b < rows; b++)
        {
            Console.Write(symbol);
        }
        Console.WriteLine();
    }
}

if (firstOption == 6)
{
    Random random = new Random();
    int guess;
    int guesses;
    String response;
    int number;
    bool playAgain = true;
    Console.WriteLine("[1] Easy Mode");
    Console.WriteLine("[2] Medium Mode");
    Console.WriteLine("[3] Hard Mode");
    Console.WriteLine("[4] Insane Mode");
    Console.WriteLine("[5] GOD MODE");
    Console.WriteLine("[6] Random [BROKEN]");
    Console.Write("Option: ");
    int level = Convert.ToInt32(Console.ReadLine());
    if (level == 1)
    {
        int min = 1;
        int max = 20;
        while (playAgain)
        {
            guess = 0;
            guesses = 0;
            number = random.Next(min, max + 1);
            Console.WriteLine("I've thought of a number between " + min + " - " + max);
            Console.WriteLine("Guess my number!");
            while (guess != number)
            {
                Console.Write("Guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > number)
                {
                    Console.WriteLine("Too high");
                }
                else if (guess < number)
                {
                    Console.WriteLine("Too low");
                }
                guesses++;

            }
            Console.WriteLine("YOU WIN!");
            Console.WriteLine("The number was " + number);
            Console.WriteLine("It took you " + guesses + " guesses");
            Console.Write("Would you like to play again [Y/N]: ");
            response = Console.ReadLine();
            response = response.ToUpper();
            if (response == "Y")
            {
                playAgain = true;
            }
            else if (response == "N")
            {
                Console.WriteLine("Thank you for playing!");
                playAgain = false;
            }
            else
            {
                Console.WriteLine("You didn't enter Y or N!");
            }

        }
    }
    if (level == 2)
    {
        int min = 1;
        int max = 50;
        while (playAgain)
        {
            guess = 0;
            guesses = 0;
            number = random.Next(min, max + 1);
            Console.WriteLine("I've thought of a number between " + min + " - " + max);
            Console.WriteLine("Guess my number!");
            while (guess != number)
            {
                Console.Write("Guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > number)
                {
                    Console.WriteLine("Too high");
                }
                else if (guess < number)
                {
                    Console.WriteLine("Too low");
                }
                guesses++;

            }
            Console.WriteLine("YOU WIN!");
            Console.WriteLine("The number was " + number);
            Console.WriteLine("It took you " + guesses + " guesses");
            Console.Write("Would you like to play again [Y/N]: ");
            response = Console.ReadLine();
            response = response.ToUpper();
            if (response == "Y")
            {
                playAgain = true;
            }
            else if (response == "N")
            {
                playAgain = false;
                Console.WriteLine("Thank you for playing!");
            }
            else
            {
                Console.WriteLine("You didn't enter Y or N!");
            }

        }
    }
    if (level == 3)
    {
        int min = 1;
        int max = 100;
        while (playAgain)
        {
            guess = 0;
            guesses = 0;
            number = random.Next(min, max + 1);
            Console.WriteLine("I've thought of a number between " + min + " - " + max);
            Console.WriteLine("Guess my number!");
            while (guess != number)
            {
                Console.Write("Guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > number)
                {
                    Console.WriteLine("Too high");
                }
                else if (guess < number)
                {
                    Console.WriteLine("Too low");
                }
                guesses++;

            }
            Console.WriteLine("YOU WIN!");
            Console.WriteLine("The number was " + number);
            Console.WriteLine("It took you " + guesses + " guesses");
            Console.Write("Would you like to play again [Y/N]: ");
            response = Console.ReadLine();
            response = response.ToUpper();
            if (response == "Y")
            {
                playAgain = true;
            }
            else if (response == "N")
            {
                playAgain = false;
                Console.WriteLine("Thank you for playing!");
            }
            else
            {
                Console.WriteLine("You didn't enter Y or N!");
            }

        }
    }
    if (level == 4)
    {
        int min = 1;
        int max = 500;
        while (playAgain)
        {
            guess = 0;
            guesses = 0;
            number = random.Next(min, max + 1);
            Console.WriteLine("I've thought of a number between " + min + " - " + max);
            Console.WriteLine("Guess my number!");
            while (guess != number)
            {
                Console.Write("Guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > number)
                {
                    Console.WriteLine("Too high");
                }
                else if (guess < number)
                {
                    Console.WriteLine("Too low");
                }
                guesses++;

            }
            Console.WriteLine("YOU WIN!");
            Console.WriteLine("The number was " + number);
            Console.WriteLine("It took you " + guesses + " guesses");
            Console.Write("Would you like to play again [Y/N]: ");
            response = Console.ReadLine();
            response = response.ToUpper();
            if (response == "Y")
            {
                playAgain = true;
            }
            else if (response == "N")
            {
                playAgain = false;
                Console.WriteLine("Thank you for playing!");
            }
            else
            {
                Console.WriteLine("You didn't enter Y or N!");
            }

        }
    }
    if (level == 5)
    {
        int min = 1;
        int max = 1000;
        while (playAgain)
        {
            guess = 0;
            guesses = 0;
            number = random.Next(min, max + 1);
            Console.WriteLine("I've thought of a number between " + min + " - " + max);
            Console.WriteLine("Guess my number!");
            while (guess != number)
            {
                Console.Write("Guess: ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess != number)
                {
                    Console.WriteLine("Incorrect");
                }

                guesses++;

            }
            Console.WriteLine("YOU WIN!");
            Console.WriteLine("The number was " + number);
            Console.WriteLine("It took you " + guesses + " guesses");
            Console.Write("Would you like to play again [Y/N]: ");
            response = Console.ReadLine();
            response = response.ToUpper();
            if (response == "Y")
            {
                playAgain = true;
            }
            else if (response == "N")
            {
                playAgain = false;
                Console.WriteLine("Thank you for playing!");
            }
            else
            {
                Console.WriteLine("You didn't enter Y or N!");
            }

        }
    }
    if (level == 6)
    {
        Console.WriteLine("[1] Easy Random");
        int levelRandom = Convert.ToInt32(Console.ReadLine());
        if (levelRandom == 1)
        {
            int min = random.Next(1, 10);
            int max = random.Next(1, 20);
            while (playAgain)
            {
                guess = 0;
                guesses = 0;
                number = random.Next(min, max + 1);
                Console.WriteLine("I've thought of a number between " + min + " - " + max);
                Console.WriteLine("Guess my number!");
                while (guess != number)
                {
                    Console.Write("Guess: ");
                    guess = Convert.ToInt32(Console.ReadLine());
                    if (guess > number)
                    {
                        Console.WriteLine("Too high");
                    }
                    else if (guess < number)
                    {
                        Console.WriteLine("Too low");
                    }
                    guess++;

                }
                Console.WriteLine("YOU WIN!");
                Console.WriteLine("The number was " + number);
                Console.WriteLine("It took you " + guesses + " guesses");
                Console.Write("Would you like to play again [Y/N]: ");
                response = Console.ReadLine();
                response = response.ToUpper();
                if (response == "Y")
                {
                    playAgain = true;
                }
                else if (response == "N")
                {
                    playAgain = false;
                    Console.WriteLine("Thank you for playing!");
                }
                else
                {
                    Console.WriteLine("You didn't enter Y or N!");
                }
            }
        }
    }
}

Console.ReadKey();
